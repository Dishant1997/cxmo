const express = require('express');

const router = express.Router();

const wallet = require('./wallet.routes');
const token = require('./token.routes');
/** about api */
const about = require('./about.routes');
/** video api */
const video = require('./video.routes');
/** authentication api */
const auth = require('./authentication.routes');

router.use('/wallet', wallet);
router.use('/token', token);
router.use('/api/v1/about', about);
router.use('/api/v1/video', video);
router.use('/api/v1/', auth); 
 

module.exports = router; 