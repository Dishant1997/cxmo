const secret = '2d7714d4-fdc0-4716-a645-f9efa8f0cbd5';
module.exports = {
    secret
};